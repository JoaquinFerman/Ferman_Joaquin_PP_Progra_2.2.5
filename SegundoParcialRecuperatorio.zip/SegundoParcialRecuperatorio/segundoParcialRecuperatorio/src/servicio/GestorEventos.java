package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

import modelo.Evento;

public class GestorEventos<T extends Evento & Comparable<T>> {
    private List<T> elementos;

    public GestorEventos(){
        elementos = new ArrayList<>();
    }

    public void agregar(T obj){
        elementos.add(obj);
    }

    public T get(int i){
        return elementos.get(i);
    }

    public void remover(int i){
        elementos.remove(i);
    }

    public void ordenar(Comparator<T> comp){
        Collections.sort(elementos, comp);
    }

    public void ordenarNatural(){
        Collections.sort(elementos);
    }

    public void limpiar(){
        elementos.clear();
    }

    public List<T> filtrar(Predicate<T> comp){
        List<T> aux = new ArrayList<>();
        for(T obj : elementos){
            if(comp.test(obj)){
                aux.add(obj);
            }
        }
        return aux;
    }

    public List<T> buscarPorRango(LocalDate c1, LocalDate c2){
        List<T> aux = new ArrayList<>();

        for(T e : elementos){
            if(e.getFecha().compareTo(c1) >= 0 && e.getFecha().compareTo(c2) <= 0){
                aux.add(e);
            }
        }
        return aux;
    }

    public void mostrarTodos(){
        for(Evento e : elementos){
            System.out.println(e);
        }
    }

    public void guardarEnCSV(String path){
        File file = new File(path);

        try{
            if(!file.exists()){
                file.createNewFile();
            }
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }

        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            for(T obj : elementos){
                bw.write(obj.toCSV() + "\n");
            }
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> f){
        List<T> toReturn = new ArrayList<>();

        try(BufferedReader br = new BufferedReader(new FileReader(path))){
            String line;
            while((line = br.readLine()) != null){
                if(line.endsWith("\n")){
                    line = line.substring(line.length()-1);
                }
                
                T obj = f.apply(line);
                toReturn.add(obj);
            }
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
        elementos = toReturn;
    }

    public void guardarEnBinario(String path){
    try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(path))){
        out.writeObject(elementos);
        } catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException{
        try(ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
            elementos = (List<T>) input.readObject();
            System.out.println("Objeto recuperado");
        } catch(IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());;
        }
    }
}
