package modelo;

import java.time.LocalDate;

public class EventoMusical extends Evento implements Comparable<EventoMusical>{
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero){
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista(){ return artista; }

    public GeneroMusical getGenero(){ return genero; }

    @Override
    public int compareTo(EventoMusical obj) {
        return getFecha().compareTo(obj.getFecha());
    }

    @Override
    public String toCSV() {
        return super.toCSV() + String.format(",%s,%s", artista, genero);
        // Recibe el incompleto de arriba y lo completa
    }

    public static EventoMusical fromCSV(String line){
        if(line.endsWith("\n")){
            line = line.substring(line.length()-1);
        }
        String[] data = line.split(",");
        EventoMusical toReturn = new EventoMusical(Integer.parseInt(data[0]), data[1], LocalDate.parse(data[2]), data[3], GeneroMusical.valueOf(data[4].toUpperCase()));
        return toReturn;
    }

    @Override
    public String toString(){
        return super.toString() + String.format(", artista:%s, genero:%s}", artista, genero);
    }
}
