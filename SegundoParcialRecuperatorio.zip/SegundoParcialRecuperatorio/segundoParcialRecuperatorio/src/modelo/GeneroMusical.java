package modelo;

public enum GeneroMusical {
    POP,
    ROCK,
    JAZZ,
    CLASICA,
    ELECTRONICA
}
